package com.example.diabetes.ui.login

import androidx.appcompat.app.AppCompatActivity

class Result : AppCompatActivity() {
}
